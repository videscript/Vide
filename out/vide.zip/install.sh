echo '● Copying resources'

sudo cp ./*.js /usr/bin/Vide
sudo cp vide /usr/bin
sudo cp ../node_modules /usr/bin/Vide


echo '● Finished install'
